/*
=====================================
Name: Shivam Choudhury
Roll number: 22CS10072
Link of the pcap file: https://drive.google.com/file/d/1fvfTZuj6z3R4I37ZmPU0SRMb9CpKSWsG/view?usp=sharing
=====================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024

void send_message(int sockfd, struct sockaddr_in *client_addr, socklen_t client_len, const char *message)
{
    sendto(sockfd, message, strlen(message), 0, (struct sockaddr *)client_addr, client_len);
}

void receive_message(int sockfd, struct sockaddr_in *client_addr, socklen_t client_len, char *message)
{
    recvfrom(sockfd, message, BUFFER_SIZE, 0, (struct sockaddr *)client_addr, &client_len);
}

int main()
{
    int port = 5000;
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];
    socklen_t client_len = sizeof(client_addr);

    // Create socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Configure server address
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    // Bind the socket
    bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr));

    printf("Server is listening on port %d...\n", port);

    // Receive filename
    memset(buffer, 0, BUFFER_SIZE);
    receive_message(sockfd, &client_addr, client_len, buffer);
    printf("Received file request: %s\n", buffer);

    FILE *file = fopen(buffer, "r");

    // Send HELLO
    fgets(buffer, BUFFER_SIZE, file); // Read HELLO
    send_message(sockfd, &client_addr, client_len, buffer);
    printf("Sent: %s", buffer);

    // Send file contents word by word
    while (fgets(buffer, BUFFER_SIZE, file))
    {
        send_message(sockfd, &client_addr, client_len, buffer);
        printf("Sent: %s", buffer);

        // Wait for acknowledgment (WORDi request)
        receive_message(sockfd, &client_addr, client_len, buffer);
    }

    fclose(file);
    printf("File transfer completed. Code terminating...\n");

    close(sockfd);
    return 0;
}
