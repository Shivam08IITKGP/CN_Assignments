/*
=====================================
Name: Shivam Choudhury
Roll number: 22CS10072
Link of the pcap file: https://drive.google.com/file/d/1fvfTZuj6z3R4I37ZmPU0SRMb9CpKSWsG/view?usp=sharing
=====================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024


void send_message(int sockfd, struct sockaddr_in *server_addr, socklen_t server_len, const char *message)
{
    sendto(sockfd, message, strlen(message), 0, (struct sockaddr *)server_addr, server_len);
}

void recieve_message(int sockfd, struct sockaddr_in *server_addr, socklen_t server_len, char *message)
{
    recvfrom(sockfd, message, BUFFER_SIZE, 0, (struct sockaddr *)server_addr, &server_len);
}

int main()
{
    int port = 5000;
    const char *file_name = "22CS10072_File1.txt";
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    socklen_t server_len = sizeof(server_addr);

    // Create socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Configure server address
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    // Send filename
    send_message(sockfd, &server_addr, server_len, file_name);

    // Receive HELLO or NOTFOUND
    recieve_message(sockfd, &server_addr, server_len, buffer);

    if (strncmp(buffer, "NOTFOUND", 8) == 0)
    {
        fprintf(stderr, "Server response: %s\n", buffer);
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Open file for writing
    FILE *file = fopen("OUTPUT.txt", "w");
    fprintf(file, "%s", buffer);

    int i = 0;
    // Receive and save file contents
    while (1)
    {
        memset(buffer, 0, sizeof(buffer));
        sprintf(buffer, "WORD%d", ++i);
        send_message(sockfd, &server_addr, server_len, buffer);

        memset(buffer, 0, sizeof(buffer));
        recieve_message(sockfd, &server_addr, server_len, buffer);

        fprintf(file, "%s", buffer);
        
        if (strncmp(buffer, "FINISH", 6) == 0)
        {
            break;
        }
    }

    fclose(file);
    printf("File received successfully.\n");

    close(sockfd);
    return 0;
}
